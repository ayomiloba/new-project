-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Nov 08, 2021 at 10:12 AM
-- Server version: 5.7.31
-- PHP Version: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hms`
--

-- --------------------------------------------------------

--
-- Table structure for table `checks`
--

DROP TABLE IF EXISTS `checks`;
CREATE TABLE IF NOT EXISTS `checks` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `con` int(11) NOT NULL,
  `pat` int(11) NOT NULL,
  `complaint` text NOT NULL,
  `allegies` text NOT NULL,
  `current_meds` text NOT NULL,
  `temps` text NOT NULL,
  `heart_rate` text NOT NULL,
  `blood_pressure` text NOT NULL,
  `resp_rate` text NOT NULL,
  `oxy_sat` text NOT NULL,
  `comment` text NOT NULL,
  `date_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `con_check` (`con`),
  KEY `pat_check` (`pat`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `checks`
--

INSERT INTO `checks` (`id`, `con`, `pat`, `complaint`, `allegies`, `current_meds`, `temps`, `heart_rate`, `blood_pressure`, `resp_rate`, `oxy_sat`, `comment`, `date_time`) VALUES
(1, 2, 1, 'hgjhgjhg', 'hjgjhgjhg', 'jhghjghj', 'gjhgjhg', 'jhghjg', 'jhghj', 'gjh', 'gjhg', 'jhjhgjhgjh', '2021-10-22 20:56:57'),
(2, 2, 1, 'hgjhgjhg', 'hjgjhgjhg', 'jhghjghj', 'gjhgjhg', 'jhghjg', 'jhghj', 'gjh', 'gjhg', 'jhjhgjhgjh', '2021-10-22 20:58:03'),
(3, 2, 1, 'hgjhgjhg', 'hjgjhgjhg', 'jhghjghj', 'gjhgjhg', 'jhghjg', 'jhghj', 'gjh', 'gjhg', 'jhjhgjhgjh', '2021-10-22 21:24:47');

-- --------------------------------------------------------

--
-- Table structure for table `cons`
--

DROP TABLE IF EXISTS `cons`;
CREATE TABLE IF NOT EXISTS `cons` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` int(11) NOT NULL DEFAULT '1',
  `firstname` varchar(40) NOT NULL,
  `lastname` varchar(40) NOT NULL,
  `gender` varchar(1) NOT NULL,
  `dob` date NOT NULL,
  `addr` text NOT NULL,
  `phone` varchar(11) NOT NULL,
  `nok` varchar(255) NOT NULL,
  `nok_phone` varchar(11) NOT NULL,
  `specialty` varchar(255) NOT NULL,
  `on_call` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `type_con` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cons`
--

INSERT INTO `cons` (`id`, `type`, `firstname`, `lastname`, `gender`, `dob`, `addr`, `phone`, `nok`, `nok_phone`, `specialty`, `on_call`) VALUES
(1, 6, 'Joshua', 'Olaniiyi', 'M', '1993-07-27', '33 shonde street ijesha lagos', '89903405', 'me', '89089', 'Dentist', 1),
(2, 7, 'Tomi', 'Olaniiyi', 'M', '1997-11-21', '33 shonde street ijesha lagos', '89903405', 'me', '89089', 'Lab Analyst', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pats`
--

DROP TABLE IF EXISTS `pats`;
CREATE TABLE IF NOT EXISTS `pats` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(40) NOT NULL,
  `lastname` varchar(40) NOT NULL,
  `room` int(11) NOT NULL DEFAULT '34',
  `gender` varchar(1) NOT NULL,
  `dob` date NOT NULL,
  `phone` varchar(11) NOT NULL,
  `addr` text NOT NULL,
  `admitted` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `nok` varchar(255) NOT NULL,
  `nok_phone` varchar(11) NOT NULL,
  `discharged` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  KEY `room_pat` (`room`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pats`
--

INSERT INTO `pats` (`id`, `firstname`, `lastname`, `room`, `gender`, `dob`, `phone`, `addr`, `admitted`, `nok`, `nok_phone`, `discharged`) VALUES
(1, 'Dele', 'Momodu', 13, 'M', '2021-10-13', '08068685952', 'sdfSDgadgd', '2021-10-19 23:15:22', 'dgdagdafg', '89089', 0),
(8, 'Dele', 'Momodu', 3, 'M', '2021-10-13', '08068685952', 'sdfSDgadgd', '2021-10-19 23:15:22', 'dgdagdafg', '89089', 0),
(16, 'Joshua', 'Olaniyi', 25, 'M', '1762-03-03', '08068685952', 'Postgraduate College\r\nRoom D6', '2021-10-20 11:56:09', 'Joshua', '2353464576', 0),
(17, 'Joshua', 'Olaniyi', 34, 'M', '1762-03-03', '08068685952', 'Postgraduate College\r\nRoom D6', '2021-10-20 11:56:40', 'Joshua', '2353464576', 1),
(18, 'Joshua', 'Olaniyi', 34, 'M', '1762-03-03', '08068685952', 'Postgraduate College\r\nRoom D6', '2021-10-20 11:57:27', 'Joshua', '2353464576', 1);

-- --------------------------------------------------------

--
-- Table structure for table `rooms`
--

DROP TABLE IF EXISTS `rooms`;
CREATE TABLE IF NOT EXISTS `rooms` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ward` int(11) NOT NULL,
  `capacity` int(11) NOT NULL DEFAULT '4',
  `curr_capacity` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `room_ward` (`ward`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `rooms`
--

INSERT INTO `rooms` (`id`, `ward`, `capacity`, `curr_capacity`) VALUES
(1, 6, 4, 0),
(2, 9, 4, 2),
(3, 8, 4, -1),
(4, 10, 4, 0),
(5, 2, 4, 4),
(6, 3, 4, 0),
(7, 4, 4, -1),
(8, 5, 4, 4),
(9, 7, 4, 0),
(10, 7, 4, 0),
(11, 1, 4, -1),
(12, 6, 4, 0),
(13, 9, 4, 1),
(14, 8, 4, 4),
(15, 10, 4, 0),
(16, 2, 4, 0),
(17, 3, 4, 4),
(18, 4, 4, 0),
(19, 5, 4, 0),
(20, 7, 4, 0),
(21, 7, 4, 0),
(22, 1, 4, 0),
(23, 6, 4, 0),
(24, 9, 4, 0),
(25, 8, 4, 1),
(26, 10, 4, 0),
(27, 2, 4, 0),
(28, 3, 4, 0),
(29, 4, 4, 0),
(30, 5, 4, 0),
(31, 7, 4, 0),
(32, 7, 4, 0),
(33, 1, 4, 0),
(34, 11, 999999, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `con` int(11) DEFAULT NULL,
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `con_user` (`con`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `con`, `username`, `password`) VALUES
(1, 1, 'josh', 'admin');

-- --------------------------------------------------------

--
-- Table structure for table `user_types`
--

DROP TABLE IF EXISTS `user_types`;
CREATE TABLE IF NOT EXISTS `user_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_types`
--

INSERT INTO `user_types` (`id`, `description`) VALUES
(1, 'Others'),
(2, 'Technician'),
(3, 'Doctor'),
(4, 'Matron'),
(5, 'Nurse'),
(6, 'Admin'),
(7, 'Analyst');

-- --------------------------------------------------------

--
-- Table structure for table `wards`
--

DROP TABLE IF EXISTS `wards`;
CREATE TABLE IF NOT EXISTS `wards` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ward` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `wards`
--

INSERT INTO `wards` (`id`, `ward`) VALUES
(1, 'Surgery'),
(2, 'Obstetrics and Gynaecology'),
(3, 'Oncology'),
(4, 'Orthopaedic surgery'),
(5, 'Paediatric ward'),
(6, 'Children emergency'),
(7, 'Special care baby unit'),
(8, 'Dialysis'),
(9, 'Eye ward'),
(10, 'Intensive care unit (ICU)'),
(11, 'Unassigned');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `checks`
--
ALTER TABLE `checks`
  ADD CONSTRAINT `con_check` FOREIGN KEY (`con`) REFERENCES `cons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `pat_check` FOREIGN KEY (`pat`) REFERENCES `pats` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `cons`
--
ALTER TABLE `cons`
  ADD CONSTRAINT `type_con` FOREIGN KEY (`type`) REFERENCES `user_types` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pats`
--
ALTER TABLE `pats`
  ADD CONSTRAINT `room_pat` FOREIGN KEY (`room`) REFERENCES `rooms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `rooms`
--
ALTER TABLE `rooms`
  ADD CONSTRAINT `room_ward` FOREIGN KEY (`ward`) REFERENCES `wards` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `con_user` FOREIGN KEY (`con`) REFERENCES `cons` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
