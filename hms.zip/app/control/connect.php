<?php
    $host = "localhost";
    $user = "root";
    $pass = "";
    $db = "hms";

    $conn = new mysqli($host, $user, $pass, $db);
    if($conn->connect_error){
        die("Connection to Database failed: ". $conn->connect_error);
    }
?>
