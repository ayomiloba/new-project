<?php
    class SQL_Operations{
        function __contruct(){
            require "connect.php";
            require 'PHPMailer/PHPMailer/autoload.php';
        }


//Get Functions
        public function getPatient($id){
            require "connect.php";
            try{
                $sql = "SELECT * FROM pats WHERE id = '".$id."' Limit 1";
                    $rs = $conn -> query($sql);
                    if($rs->num_rows>0){
                        $row = $rs->fetch_assoc();
                        $pat = array("id"=>$row["id"], "firstname"=>$row["firstname"], "lastname"=>$row["lastname"], "room"=>$row["room"], "gender"=>$row["gender"],"dob"=>$row["dob"], "phone"=>$row["phone"], "addr"=>$row["addr"], "admitted"=>$row["admitted"], "nok"=>$row["nok"], "nok_phone"=>$row["nok_phone"], "discharged"=>$row["discharged"]);
                        return $pat;
                    }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        public function getPatients(){
            require "connect.php";
            try{
                $sql = "SELECT * FROM pats ORDER BY admitted DESC";
                $pats = array();
                $rs = $conn->query($sql);
                if($rs->num_rows>0){
                    while($row = $rs->fetch_assoc()){
                        $pat = array("id"=>$row["id"], "firstname"=>$row["firstname"], "lastname"=>$row["lastname"], "room"=>$row["room"], "gender"=>$row["gender"],"dob"=>$row["dob"], "phone"=>$row["phone"], "addr"=>$row["addr"], "admitted"=>$row["admitted"], "nok"=>$row["nok"], "nok_phone"=>$row["nok_phone"], "discharged"=>$row["discharged"]);

                        array_push($pats,$pat);
                        
                    }
                    return $pats;
                }else{
                    return $pats;
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        public function getPatientsByWard($ward_id){
            require "connect.php";
            try{
                $sql = "SELECT a.*, b.ward FROM pats a, rooms b WHERE a.room = b.id  and b.ward= '".$ward_id."' ORDER BY admitted DESC";
                $pats = array();
                $rs = $conn->query($sql);
                if($rs->num_rows>0){
                    while($row = $rs->fetch_assoc()){
                        $pat = array("id"=>$row["id"], "firstname"=>$row["firstname"], "lastname"=>$row["lastname"], "room"=>$row["room"], "gender"=>$row["gender"],"dob"=>$row["dob"], "phone"=>$row["phone"], "addr"=>$row["addr"], "admitted"=>$row["admitted"], "nok"=>$row["nok"], "nok_phone"=>$row["nok_phone"], "discharged"=>$row["discharged"]);

                        array_push($pats,$pat);
                        
                    }
                    return $pats;
                }else{
                    return $pats;
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        public function getPatientsByRoom($room_id){
            require "connect.php";
            try{
                $sql = "SELECT * FROM pat WHERE room = '".$room_id."' ORDER BY admitted DESC";
                $pats = array();
                $rs = $conn->query($sql);
                if($rs->num_rows>0){
                    while($row = $rs->fetch_assoc()){
                        $pat = array("id"=>$row["id"], "firstname"=>$row["firstname"], "lastname"=>$row["lastname"], "room"=>$row["room"], "gender"=>$row["gender"],"dob"=>$row["dob"], "phone"=>$row["phone"], "addr"=>$row["addr"], "admitted"=>$row["admitted"], "nok"=>$row["nok"], "nok_phone"=>$row["nok_phone"], "discharged"=>$row["discharged"]);

                        array_push($pats,$pat);
                        
                    }
                    return $pats;
                }else{
                    return $pats;
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        public function getConsultant($id){
            require "connect.php";
            try{
                $sql = "SELECT a.*, b.description FROM cons a left join user_types b on a.type = b.id WHERE a.id = '".$id."' Limit 1";
                    $rs = $conn -> query($sql);
                    if($rs->num_rows>0){
                        $row = $rs->fetch_assoc();
                        $con = array("id"=>$row["id"], "firstname"=>$row["firstname"], "lastname"=>$row["lastname"], "type"=>$row["type"], "gender"=>$row["gender"],"dob"=>$row["dob"], "phone"=>$row["phone"], "addr"=>$row["addr"], "specialty"=>$row["specialty"], "nok"=>$row["nok"], "nok_phone"=>$row["nok_phone"], "on_call"=>$row["on_call"],"designation"=>$row["description"]);
                        return $con;
                    }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        public function getConsultants(){
            require "connect.php";
            try{
                $sql = "SELECT a.*, b.description FROM cons a left join user_types b on a.type = b.id";
                $cons = array();
                $rs = $conn->query($sql);
                if($rs->num_rows>0){
                    while($row = $rs->fetch_assoc()){
                        $con = array("id"=>$row["id"], "firstname"=>$row["firstname"], "lastname"=>$row["lastname"], "type"=>$row["type"], "gender"=>$row["gender"],"dob"=>$row["dob"], "phone"=>$row["phone"], "addr"=>$row["addr"], "specialty"=>$row["specialty"], "nok"=>$row["nok"], "nok_phone"=>$row["nok_phone"],"on_call"=>$row["on_call"],"designation"=>$row["description"]);

                        array_push($cons,$con);
                        
                    }
                    return $cons;
                }else{
                    return $cons;
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }


        public function getRoom($id){
            require "connect.php";
            try{
                $sql = "SELECT * FROM rooms WHERE id = '".$id."' Limit 1";
                    $rs = $conn -> query($sql);
                    if($rs->num_rows>0){
                        $row = $rs->fetch_assoc();
                        $room = array("id"=>$row["id"], "ward"=>$row["ward"], "capacity"=>$row["capacity"], "curr_capacity"=>$row["curr_capacity"]);
                        return $room;
                    }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        public function getRooms(){
            require "connect.php";
            try{
                $sql = "SELECT * FROM rooms where id != 34";
                $rooms = array();
                $rs = $conn->query($sql);
                if($rs->num_rows>0){
                    while($row = $rs->fetch_assoc()){
                        $room = array("id"=>$row["id"], "ward"=>$row["ward"], "capacity"=>$row["capacity"], "curr_capacity"=>$row["curr_capacity"]);

                        array_push($rooms,$room);
                        
                    }
                    return $rooms;
                }else{
                    return $rooms;
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        public function getVacantRooms(){
            require "connect.php";
            try{
                $sql = "SELECT * FROM rooms where capacity-curr_capacity > 0 and id != 34 ORDER BY ward";
                $rooms = array();
                $rs = $conn->query($sql);
                if($rs->num_rows>0){
                    while($row = $rs->fetch_assoc()){
                        $room = array("id"=>$row["id"], "ward"=>$row["ward"], "capacity"=>$row["capacity"], "curr_capacity"=>$row["curr_capacity"]);

                        array_push($rooms,$room);
                        
                    }
                    return $rooms;
                }else{
                    return $rooms;
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        public function getRoomsByWard($ward_id){
            require "connect.php";
            try{
                $sql = "SELECT * FROM rooms WHERE ward = '".$ward_id."'";
                $rooms = array();
                $rs = $conn->query($sql);
                if($rs->num_rows>0){
                    while($row = $rs->fetch_assoc()){
                        $room = array("id"=>$row["id"], "ward"=>$row["ward"], "capacity"=>$row["capacity"], "curr_capacity"=>$row["curr_capacity"]);

                        array_push($rooms,$room);
                        
                    }
                    return $rooms;
                }else{
                    return $rooms;
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        public function getWard($id){
            require "connect.php";
            try{
                $sql = "SELECT * FROM wards WHERE id = '".$id."' Limit 1";
                    $rs = $conn -> query($sql);
                    if($rs->num_rows>0){
                        $row = $rs->fetch_assoc();
                        $ward = array("id"=>$row["id"], "ward"=>$row["ward"]);
                        return $ward;
                    }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        public function getWards(){
            require "connect.php";
            try{
                $sql = "SELECT * FROM wards";
                $wards = array();
                $rs = $conn->query($sql);
                if($rs->num_rows>0){
                    while($row = $rs->fetch_assoc()){
                        $ward = array("id"=>$row["id"], "ward"=>$row["ward"]);

                        array_push($wards,$ward);
                        
                    }
                    return $wards;
                }else{
                    return $wards;
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        public function getUserTypes(){
            require "connect.php";
            try{
                $sql = "SELECT * FROM user_types";
                $types = array();
                $rs = $conn->query($sql);
                if($rs->num_rows>0){
                    while($row = $rs->fetch_assoc()){
                        $type = array("id"=>$row["id"], "desc"=>$row["description"]);

                        array_push($wards,$ward);
                        
                    }
                    return $types;
                }else{
                    return $types;
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        public function getCheck($id){
            require "connect.php";
            try{
                $sql = "SELECT * FROM checks WHERE id = '".$id."' Limit 1";
                    $rs = $conn -> query($sql);
                    if($rs->num_rows>0){
                        $row = $rs->fetch_assoc();
                        $check = array(
                            "id"=> $row["id"],
                            "con"=> $row["con"],
                            "pat"=> $row["pat"],
                            "complaint"=> $row["complaint"],
                            "allegies"=> $row["allegies"],
                            "current_meds"=> $row["current_meds"],
                            "temps"=> $row["temps"],
                            "heart_rate"=> $row["heart_rate"],
                            "blood_pressure"=> $row["blood_pressure"],
                            "resp_rate"=> $row["resp_rate"],
                            "oxy_sat"=> $row["oxy_sat"],
                            "comment"=> $row["comment"],
                            "date_time"=> $row["date_time"]
                        );
                        return $check;
                    }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        public function getChecksByPatient($pat_id){
            require "connect.php";
            try{
                $sql = "SELECT * FROM checks WHERE pat = '".$pat_id."' ORDER BY date_time DESC";
                $checks = array();
                $rs = $conn->query($sql);
                if($rs->num_rows>0){
                    while($row = $rs->fetch_assoc()){
                        $check = array(
                            "id"=> $row["id"],
                            "con"=> $row["con"],
                            "pat"=> $row["pat"],
                            "complaint"=> $row["complaint"],
                            "allegies"=> $row["allegies"],
                            "current_meds"=> $row["current_meds"],
                            "temps"=> $row["temps"],
                            "heart_rate"=> $row["heart_rate"],
                            "blood_pressure"=> $row["blood_pressure"],
                            "resp_rate"=> $row["resp_rate"],
                            "oxy_sat"=> $row["oxy_sat"],
                            "comment"=> $row["comment"],
                            "date_time"=> $row["date_time"]
                        );

                        array_push($checks,$check);
                        
                    }
                    return $checks;
                }else{
                    return $checks;
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        public function getChecksByConsultant($con_id){
            require "connect.php";
            try{
                $sql = "SELECT * FROM checks WHERE con = '".$con_id."' ORDER BY date_time DESC";
                $checks = array();
                $rs = $conn->query($sql);
                if($rs->num_rows>0){
                    while($row = $rs->fetch_assoc()){
                        $check = array(
                            "id"=> $row["id"],
                            "con"=> $row["con"],
                            "pat"=> $row["pat"],
                            "complaint"=> $row["complaint"],
                            "allegies"=> $row["allegies"],
                            "current_meds"=> $row["current_meds"],
                            "temps"=> $row["temps"],
                            "heart_rate"=> $row["heart_rate"],
                            "blood_pressure"=> $row["blood_pressure"],
                            "resp_rate"=> $row["resp_rate"],
                            "oxy_sat"=> $row["oxy_sat"],
                            "comment"=> $row["comment"],
                            "date_time"=> $row["date_time"]
                        );

                        array_push($checks,$check);
                        
                    }
                    return $checks;
                }else{
                    return $checks;
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        

//Create Functions
        public function createPatient($firstname, $lastname, $gender, $dob, $phone, $addr, $nok, $nok_phone){
            require "connect.php";
            try{
                $sql = "INSERT INTO pats(firstname, lastname, gender,	dob, phone,	addr, admitted, nok,	nok_phone) VALUES('".$firstname. "','".$lastname. "','".$gender. "','".$dob. "','".$phone. "','".$addr. "',NOW(),'".$nok. "','".$nok_phone. "')";
                if($conn->query($sql)===TRUE){
                    return TRUE;
                }else{
                    return FALSE; 
                }
            }catch(Exception $e){
                return mysqli_error($conn).'  '.$e; 
            }
            $conn->close();
        }

        public function createConsultant($type, 	$firstname, $lastname, $gender, $dob, $addr, $phone, $nok, $nok_phone, $specialty){
            require "connect.php";
            try{
                $sql = "INSERT INTO cons(type, 	firstname, 	lastname, 	gender, 	dob, 	addr, 	phone, 	nok, 	nok_phone, 	specialty, 	on_call) VALUES('".$type. "', '".$firstname. "', '".$lastname. "', '".$gender. "', '".$dob. "', '".$addr. "', '".$phone. "', '".$nok. "', '".$nok_phone. "',	'".$specialty. "')";
                if($conn->query($sql)===TRUE){
                    return TRUE;
                }else{
                    return FALSE; 
                }
            }catch(Exception $e){
                return mysqli_error($conn).'  '.$e; 
            }
            $conn->close();
        }

        public function createCheck($con,$pat,$complaint,$allegies,$current_meds,$temps,$heart_rate,$blood_pressure,$resp_rate, 	$oxy_sat,$comment){
            require "connect.php";
            try{
                $sql = "INSERT INTO checks(con, 	pat, 	complaint, 	allegies, 	current_meds, 	temps, 	heart_rate, 	blood_pressure, 	resp_rate, 	oxy_sat, 	comment, date_time) VALUES('".$con. "',	'".$pat. "',	'".$complaint. "',	'".$allegies. "',	'".$current_meds. "',	'".$temps. "',	'".$heart_rate. "',	'".$blood_pressure. "',	'".$resp_rate. "',	'".$oxy_sat. "',	'".$comment. "', NOW())";

                
                if($conn->query($sql)===TRUE){
                    return TRUE;
                }else{
                    return FALSE; 
                }
            }catch(Exception $e){
                return mysqli_error($conn).'  '.$e; 
            }
            $conn->close();
        }


//Update Functions
        public function updatePatient($id, $firstname, $lastname, $room, $gender, $dob, $phone, $addr, $nok, $nok_phone){
            require "connect.php";
            try{
                $sql = "UPDATE pats SET firstname =  ".$firstname.",	lastname =  ".$lastname.",	room =  ".$room.",	gender =  ".$gender.",	dob =  ".$dob.",	phone =  ".$phone.",	addr =  ".$addr.",	nok =  ".$nok.",	nok_phone =  ".$nok_phone."  where id = '".$id."'";
                if($conn->query($sql)==TRUE){
                    return TRUE;
                }else{
                    return FALSE; 
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
            $conn->close();
        }

        public function deleteCheck($id){
            require "connect.php";
            try{
                $sql = "DELETE from chechks where id = '".$id."'";
                if($conn->query($sql)==TRUE){
                    return TRUE;
                }else{
                    return FALSE; 
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
            $conn->close();
        }
        public function deletePatient($id){
            require "connect.php";
            try{
                $sql = "DELETE from pats where id = '".$id."'";
                if($conn->query($sql)==TRUE){
                    return TRUE;
                }else{
                    return FALSE; 
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
            $conn->close();
        }
        public function deleteConsultant($id){
            require "connect.php";
            try{
                $sql = "DELETE from cons where id = '".$id."'";
                if($conn->query($sql)==TRUE){
                    return TRUE;
                }else{
                    return FALSE; 
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
            $conn->close();
        }

        public function vacateRoom($id){
            require "connect.php";
            
                try{
                    $sql = "UPDATE rooms SET curr_capacity = curr_capacity-1 where id = '".$id."'";
                    // return $sql;
                    if($conn->query($sql)==TRUE){
                        return TRUE;
                    }else{
                        return FALSE; 
                    }
                }catch(Exception $e){
                    echo mysqli_error($conn).'  '.$e; 
                }
            
            
            $conn->close();
        }

        public function addToRoom($id){
            require "connect.php";
            
                try{
                    $sql = "UPDATE rooms SET curr_capacity = curr_capacity+1 where id = '".$id."'";
                    if($conn->query($sql)==TRUE){
                        return TRUE;
                    }else{
                        return FALSE; 
                    }
                }catch(Exception $e){
                    echo mysqli_error($conn).'  '.$e; 
                }
            
            
            $conn->close();
        }

        public function discharge($id, $room){
            require "connect.php";
            try{
                
                $sql = "UPDATE pats SET discharged = 1, room = 34, admitted = NOW() where id = '".$id."'";
                if($conn->query($sql)==TRUE){
                    return TRUE;
                }else{
                    return FALSE; 
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
            $conn->close();
        }

        public function admit($id, $room){
            require "connect.php";
            try{
                $sql = "UPDATE pats SET discharged = 0, room = '".$room."' where id = '".$id."'";
                if($conn->query($sql)==TRUE){
                    return TRUE;
                }else{
                    return FALSE; 
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
            $conn->close();
        }

        public function updateConsultant($id, $type, 	$firstname, $lastname, $gender, $dob, $addr, $phone, $nok, $nok_phone, $specialty){
            require "connect.php";
            try{
                $sql = "UPDATE cons SET type =  ".$type.",	firstname =  ".$firstname.",	lastname =  ".$lastname.",	gender =  ".$gender.",	dob =  ".$dob.",	addr =  ".$addr.",	phone =  ".$phone.",	nok =  ".$nok.",	nok_phone =  ".$nok_phone.",	specialty =  ".$specialty." where id = '".$id."'";
                if($conn->query($sql)==TRUE){
                    return TRUE;
                }else{
                    return FALSE; 
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
            $conn->close();
        }

        public function clockIn($id){
            require "connect.php";
            try{
                $sql = "UPDATE cons SET on_call = 1 where id = '".$id."'";
                if($conn->query($sql)==TRUE){
                    return TRUE;
                }else{
                    return FALSE; 
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
            $conn->close();
        }

        public function clockOut($id){
            require "connect.php";
            try{
                $sql = "UPDATE cons SET on_call = 0 where id = '".$id."'";
                if($conn->query($sql)==TRUE){
                    return TRUE;
                }else{
                    return FALSE; 
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
            $conn->close();
        }

        public function updateCheck($id,$con, 	$pat, 	$complaint, 	$allegies, 	$current_meds, 	$temps, 	$heart_rate, 	$blood_pressure, 	$resp_rate, 	$oxy_sat, 	$comment){
            require "connect.php";
            try{
                $sql = "UPDATE checks SET con =  ".$con.",	pat =  ".$pat.",	complaint =  ".$complaint.",	allegies =  ".$allegies.",	current_meds =  ".$current_meds.",	temps =  ".$temps.",	heart_rate =  ".$heart_rate.",	blood_pressure =  ".$blood_pressure.",	resp_rate =  ".$resp_rate.",	oxy_sat =  ".$oxy_sat.",	comment =  ".$comment.",date_time = NOW() where id = '".$id."'";
                if($conn->query($sql)==TRUE){
                    return TRUE;
                }else{
                    return FALSE; 
                }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
            $conn->close();
        }

       


//Aggregate Functions
        public function getPatientCount(){
            require "connect.php";
            try{
                $sql = "SELECT count(id) as cnt FROM pats WHERE discharged = 0";
                    $rs = $conn -> query($sql);
                    if($rs->num_rows>0){
                        $row = $rs->fetch_assoc();
                        $count = $row["cnt"];
                        return $count;
                    }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }
        public function getOnCallConsultantCount(){
            require "connect.php";
            try{
                $sql = "SELECT count(id) as cnt FROM cons WHERE on_call = 1";
                    $rs = $conn -> query($sql);
                    if($rs->num_rows>0){
                        $row = $rs->fetch_assoc();
                        $count = $row["cnt"];
                        return $count;
                    }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        public function getAllConsultantCount(){
            require "connect.php";
            try{
                $sql = "SELECT count(id) as cnt FROM cons";
                    $rs = $conn -> query($sql);
                    if($rs->num_rows>0){
                        $row = $rs->fetch_assoc();
                        $count = $row["cnt"];
                        return $count;
                    }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }
        public function getRoomCount(){
            require "connect.php";
            try{
                $sql = "SELECT count(id) as cnt FROM rooms where id != 34";
                    $rs = $conn -> query($sql);
                    if($rs->num_rows>0){
                        $row = $rs->fetch_assoc();
                        $count = $row["cnt"];
                        return $count;
                    }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }

        public function getVacantRoomCount(){
            require "connect.php";
            try{
                $sql = "SELECT count(id) as cnt FROM rooms where capacity-curr_capacity > 0 and id != 34";
                    $rs = $conn -> query($sql);
                    if($rs->num_rows>0){
                        $row = $rs->fetch_assoc();
                        $count = $row["cnt"];
                        return $count;
                    }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }
//Checks
        public function checkRoom($id){
            require "connect.php";
            try{
                $sql = "SELECT capacity - curr_capacity as vacancies FROM rooms WHERE id = '".$id."'";
                    $rs = $conn -> query($sql);
                    if($rs->num_rows>0){
                        $row = $rs->fetch_assoc();
                        $vacancies = $row["vacancies"];
                        if($vacancies > 0){
                            return TRUE;
                        }else{
                            return FALSE;
                        }
                    }
            }catch(Exception $e){
                echo mysqli_error($conn).'  '.$e; 
            }
        }
//Other Fucntions
    public function formatDate($date){
        $d = date_create($date);
        return date_format($d, 'd/M/Y H:i:s');
    }

    public function login($username, $password){
        require "connect.php";
        try{
            $sql = "SELECT con FROM users WHERE username = '".$username."' AND password = '".$password."'";
            $rs = $conn->query($sql);
            if($rs->num_rows>0){
                $row = $rs->fetch_assoc();
                return $row['con'];
            }else{
                return 'no user';
            }
        }catch(Exception $e){
            echo mysqli_error($conn).'  '.$e; 
        }
        $conn->close();
    }

}
?>