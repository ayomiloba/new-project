<?php 
   
    $curr_user = $sql -> getConsultant($u);
?>
<ul class="nav navbar-nav navbar-right">
    <li>
        <a href="#">
            <p>
                <?php echo "Hello ".$curr_user['firstname'] ?>
            </p>
        </a>
    </li>
    <li>
            <p>
    <?php
        if($curr_user['on_call']==1){
            $action = '1';
            $button = 'Clock Out';
            $disable = '';
        }else{
            $action = '0';
            $button = 'Clock In';
            $disable = 'style=" display: none;"';
        }
    ?>
                <a href="handlers/clockin.php?id=<?php echo $u?>&action=<?php echo $action?>" class="btn btn-success btn-xs btn-fill"><?php echo $button?></a>
            </p>
    </li>
    <li>
        <a href="handlers/logout.php">
            <p> <i class="pe-7s-back-2"></i> Log out</p>
        </a>
    </li>
    <li class="separator hidden-lg"></li>
</ul>